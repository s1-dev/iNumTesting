package iNumTesting;

public class Tsahjkthabgpa {

	public static void main(String[] args) {
		int[][] arr = new int[2][2];
		arr[0][0] = 1;
		arr[0][1] = 2;
		arr[1][0] = 3;
		int out = 0;
		for(int i = 0; i < arr.length; i++){
		for(int j = 0; j < arr[i].length; j++){
		out = out + arr[i][j];

		}
		}
		
		System.out.println(out);
	}

}
