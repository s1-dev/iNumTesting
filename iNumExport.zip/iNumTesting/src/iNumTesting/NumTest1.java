package iNumTesting;

import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;

public class NumTest1 {

	public static void main(String[] args) throws IOException {
		NetworkInterface nI = null;
		InetAddress router = null;
		ArrayList<InetAddress> arr = new ArrayList<InetAddress>();
		
	/*	router = InetAddress.getByName("192.168.1.1");
		
		if(router.isReachable(5000)) {
			System.out.println(router.getCanonicalHostName());
		} */
		for(int i = 0; i < 255; i = i + 15) {
		//	System.out.println(i+ " thisfts sgujpianguo[asgoiuasgasga");
			int test = 0;
			if(i == 0) {
				test = i + 14;
				MultiThreadThing t1 = new MultiThreadThing(1, test);
				t1.start();
				continue;
			}
			if(i == 240) {
				test = 240 + 14;
			}
			else {
				test = i + 14;
			}
			MultiThreadThing t1 = new MultiThreadThing(i, test);
			t1.start();
		} 
	}

}
