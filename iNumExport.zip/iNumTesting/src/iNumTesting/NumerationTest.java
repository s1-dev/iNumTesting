package iNumTesting;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;

public class NumerationTest {

	public static void main(String[] args) throws SocketException {
		Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
		ArrayList<NetworkInterface> netA = new ArrayList<NetworkInterface>();
		while(nets.hasMoreElements()) {
			NetworkInterface temp = nets.nextElement();
			if(temp.isUp() && !temp.isVirtual() && !temp.isLoopback()) {
				System.out.println(temp);
				netA.add(temp);
			}
		}
	//	System.out.println(netA.size());
		
		Enumeration<InetAddress> inetAddresses = netA.get(0).getInetAddresses();
		
		while(inetAddresses.hasMoreElements()) {
			InetAddress temp = inetAddresses.nextElement();
			System.out.println(temp.getCanonicalHostName());
		}
		System.out.println(netA.get(0).getInterfaceAddresses().get(0).getNetworkPrefixLength());

	}

}
