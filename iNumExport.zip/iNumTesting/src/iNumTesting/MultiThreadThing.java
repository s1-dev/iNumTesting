package iNumTesting;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class MultiThreadThing extends Thread {
	int start = 0; int end = 0;
	public MultiThreadThing(int s, int e) {
		start  = s;
		end = e;
	}
	@Override
	public void run(){
		for(int i = start; i < end; i++) {
		//	System.out.println("test");
			Integer sI = i;
			InetAddress temp = null;
			try {
				temp = InetAddress.getByName("192.168.1." + sI); //input network portion of IPs
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				if(!temp.isReachable(5000)) {
				//	System.out.println(temp + "Is not reachable");
					continue;
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(temp + " IS REACHABLE !!!!!!!!!!!!!!");  
		}
	}
}
